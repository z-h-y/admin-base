<?php
namespace app\Models;

/**
 * OperationLog
 *
 * @property integer $id
 * @property string $username
 * @property string $userRoles
 * @property string $table
 * @property string $event
 * @property string $content
 * @property integer $recordId
 */
class OperationLog extends BaseModel {

}