(function() {
  'use strict';

  angular.module('adminApp')
    .controller('IndexCtrl', IndexCtrl);

  IndexCtrl.$inject = [];

  function IndexCtrl() {

  }

})();
