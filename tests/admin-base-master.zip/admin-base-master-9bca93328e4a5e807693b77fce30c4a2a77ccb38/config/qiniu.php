<?php

return array(
    'access_key' => env('QINIU_ACCESS_KEY'),
    'secret_key' => env('QINIU_SECRET_KEY'),
    'hub' => env('QINIU_HUB_NAME'),
);
