<?php

return array(
    'site_url' => env('PASSPORT_SSO_URL'),
    'site_id' => env('PASSPORT_SSO_ID'),
    'site_secret' => env('PASSPORT_SSO_SECRET'),
);